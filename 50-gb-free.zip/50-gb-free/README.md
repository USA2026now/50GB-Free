# 50 GB Free

A Pen created on CodePen.

Original URL: [https://codepen.io/Babu-the-selector/pen/MYbVVeg](https://codepen.io/Babu-the-selector/pen/MYbVVeg).

